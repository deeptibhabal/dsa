# Visiting popular locations in an area: BFS (adjacency list) and DFS (adjacency matrix)
from collections import deque

locations = ["A", "B", "C", "D", "E", "F", "G"]          # e.g. A=Station, B=Market ...
routes = [("A", "B"), ("A", "C"), ("B", "D"), ("B", "E"),
          ("C", "F"), ("E", "G"), ("F", "G")]            # undirected routes
idx = {name: i for i, name in enumerate(locations)}
n = len(locations)

# ---- Adjacency list (used for BFS) ----
adj_list = {v: [] for v in locations}
for u, v in routes:
    adj_list[u].append(v)
    adj_list[v].append(u)
for v in adj_list:
    adj_list[v].sort()

# ---- Adjacency matrix (used for DFS) ----
adj_matrix = [[0] * n for _ in range(n)]
for u, v in routes:
    adj_matrix[idx[u]][idx[v]] = adj_matrix[idx[v]][idx[u]] = 1


def bfs(start):
    visited, order = {start}, []
    queue = deque([start])
    while queue:
        node = queue.popleft()
        order.append(node)
        for nb in adj_list[node]:
            if nb not in visited:
                visited.add(nb)
                queue.append(nb)
    return order                                   # O(V + E)


def dfs(start):
    visited, order = [False] * n, []

    def visit(u):
        visited[u] = True
        order.append(locations[u])
        for v in range(n):                         # scan a whole matrix row: O(V)
            if adj_matrix[u][v] == 1 and not visited[v]:
                visit(v)

    visit(idx[start])
    return order                                   # O(V^2)


if __name__ == "__main__":
    print("Adjacency list:")
    for v, nbrs in adj_list.items():
        print(f"  {v}: {nbrs}")
    print("\nAdjacency matrix:")
    print("    " + "  ".join(locations))
    for i, row in enumerate(adj_matrix):
        print(f"{locations[i]} | " + "  ".join(map(str, row)))

    start = input("\nStart location (e.g. A): ").strip().upper() or "A"
    print("BFS order:", " -> ".join(bfs(start)))
    print("DFS order:", " -> ".join(dfs(start)))

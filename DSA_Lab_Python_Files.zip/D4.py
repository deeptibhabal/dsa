# Expression tree from a PREFIX expression, non-recursive post-order traversal, tree deletion
class Node:
    def __init__(self, data):
        self.data = data
        self.left = self.right = None


def build_from_prefix(expr):
    """Scan right to left; operands are pushed, an operator pops two subtrees."""
    stack = []
    for ch in reversed(expr.replace(" ", "")):
        node = Node(ch)
        if ch in "+-*/^":
            node.left = stack.pop()       # first operand
            node.right = stack.pop()      # second operand
        stack.append(node)
    return stack.pop()


def postorder_iterative(root):
    """Left -> Right -> Root using one stack and a 'last visited' pointer."""
    result, stack, last, cur = [], [], None, root
    while cur or stack:
        if cur:
            stack.append(cur)
            cur = cur.left
        else:
            peek = stack[-1]
            if peek.right and last is not peek.right:
                cur = peek.right
            else:
                result.append(peek.data)
                last = stack.pop()
    return result


def delete_tree(root):
    """Delete nodes bottom-up (post-order) without recursion; returns count deleted."""
    if not root:
        return 0
    stack, count = [root], 0
    while stack:
        node = stack.pop()
        if node.left:  stack.append(node.left)
        if node.right: stack.append(node.right)
        print(f"Deleting node: {node.data}")
        node.left = node.right = None          # break links
        count += 1
    return count


if __name__ == "__main__":
    prefix = input("Enter prefix expression (default +--a*bc/def): ").strip() or "+--a*bc/def"
    root = build_from_prefix(prefix)
    print("Post-order :", " ".join(postorder_iterative(root)))
    print("Nodes deleted:", delete_tree(root))
    root = None
# All steps are O(n) time; stack space O(h) (O(n) worst case).

# Call centre queue simulation
class Call:
    def __init__(self, customer_id, call_time):
        self.customer_id = customer_id
        self.call_time = call_time          # duration in minutes


class CallCenter:
    def __init__(self):
        self.queue = []                     # front = index 0

    def addCall(self, customerID, callTime):
        self.queue.append(Call(customerID, callTime))
        print(f"Call added: customer {customerID}, {callTime} min")

    def answerCall(self):
        if self.isQueueEmpty():
            print("No calls to answer.")
            return None
        call = self.queue.pop(0)            # first come, first served
        print(f"Answered call of customer {call.customer_id} ({call.call_time} min)")
        return call

    def viewQueue(self):
        if self.isQueueEmpty():
            print("Queue is empty.")
            return
        print("Calls in queue (front -> rear):")
        for pos, c in enumerate(self.queue, start=1):
            print(f"  {pos}. Customer ID: {c.customer_id}, Call time: {c.call_time} min")

    def isQueueEmpty(self):
        return len(self.queue) == 0


if __name__ == "__main__":
    cc = CallCenter()
    while True:
        print("\n1.Add Call  2.Answer Call  3.View Queue  4.Is Queue Empty?  5.Exit")
        ch = input("Choice: ").strip()
        if ch == "1":
            cid = input("Customer ID: ")
            t = int(input("Call time (minutes): "))
            cc.addCall(cid, t)
        elif ch == "2":
            cc.answerCall()
        elif ch == "3":
            cc.viewQueue()
        elif ch == "4":
            print("Empty" if cc.isQueueEmpty() else "Not empty")
        elif ch == "5":
            break
        else:
            print("Invalid choice.")

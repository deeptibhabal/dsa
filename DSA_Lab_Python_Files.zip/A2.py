# Linear search and binary search on customer account IDs

def linear_search(ids, target):
    """Check every element one by one. Time O(n), Space O(1)."""
    for i in range(len(ids)):
        if ids[i] == target:
            return i
    return -1


def binary_search(ids, target):
    """ids MUST be sorted. Time O(log n), Space O(1)."""
    low, high = 0, len(ids) - 1
    while low <= high:
        mid = (low + high) // 2
        if ids[mid] == target:
            return mid
        elif ids[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1


if __name__ == "__main__":
    ids = [10452, 10231, 10987, 10110, 10765, 10333, 10876, 10543]
    print("Customer IDs:", ids)

    target = int(input("Enter account ID to search: "))

    pos = linear_search(ids, target)
    print("Linear search :", f"found at index {pos}" if pos != -1 else "not found")

    sorted_ids = sorted(ids)             # binary search needs sorted data, O(n log n)
    pos = binary_search(sorted_ids, target)
    print("Binary search :", f"found at index {pos} of sorted list" if pos != -1 else "not found")

    print("""
            Best    Average    Worst     Space
Linear      O(1)    O(n)       O(n)      O(1)
Binary      O(1)    O(log n)   O(log n)  O(1)   (list must be sorted first)
""")

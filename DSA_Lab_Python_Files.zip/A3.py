# Sort employee salaries using Selection Sort and Bubble Sort

def selection_sort(arr):
    """Time O(n^2) in all cases, Space O(1)."""
    a = arr[:]
    n = len(a)
    for i in range(n - 1):
        min_idx = i
        for j in range(i + 1, n):
            if a[j] < a[min_idx]:
                min_idx = j
        a[i], a[min_idx] = a[min_idx], a[i]
    return a


def bubble_sort(arr):
    """Time O(n^2) worst/average, O(n) best (already sorted), Space O(1)."""
    a = arr[:]
    n = len(a)
    for i in range(n - 1):
        swapped = False
        for j in range(n - 1 - i):
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                swapped = True
        if not swapped:          # no swaps -> already sorted
            break
    return a


def top_five(sorted_salaries):
    """Salaries are in ascending order, so the last five are the highest."""
    return sorted_salaries[-5:][::-1]


if __name__ == "__main__":
    salaries = [45000.50, 72000.00, 38000.75, 91000.25, 56000.00,
                64000.80, 83000.10, 29000.00, 99000.99, 51000.45]
    print("Original salaries:", salaries)

    sel = selection_sort(salaries)
    print("\nSelection Sort (ascending):", sel)

    bub = bubble_sort(salaries)
    print("Bubble Sort    (ascending):", bub)

    print("\nTop five highest salaries:")
    for rank, s in enumerate(top_five(sel), start=1):
        print(f"  {rank}. {s:.2f}")

# Real-time event processing system using a Queue (FIFO)
from collections import deque


class EventQueue:
    def __init__(self):
        self.queue = deque()
        self.next_id = 1

    def add_event(self, description):
        self.queue.append((self.next_id, description))      # enqueue at rear, O(1)
        print(f"Event #{self.next_id} added: {description}")
        self.next_id += 1

    def process_next(self):
        if not self.queue:
            print("No events to process.")
            return
        eid, desc = self.queue.popleft()                    # dequeue from front, O(1)
        print(f"Processed event #{eid}: {desc}")

    def display_pending(self):
        if not self.queue:
            print("No pending events.")
            return
        print("Pending events (oldest first):")
        for eid, desc in self.queue:
            print(f"  #{eid}: {desc}")

    def cancel_event(self, event_id):                       # O(n) search
        for item in self.queue:
            if item[0] == event_id:
                self.queue.remove(item)
                print(f"Event #{event_id} cancelled.")
                return
        print("Event not found (already processed or invalid ID).")


if __name__ == "__main__":
    eq = EventQueue()
    while True:
        print("\n1.Add Event  2.Process Next  3.Display Pending  4.Cancel Event  5.Exit")
        ch = input("Choice: ").strip()
        if ch == "1":
            eq.add_event(input("Event description: "))
        elif ch == "2":
            eq.process_next()
        elif ch == "3":
            eq.display_pending()
        elif ch == "4":
            eq.cancel_event(int(input("Event ID to cancel: ")))
        elif ch == "5":
            break
        else:
            print("Invalid choice.")

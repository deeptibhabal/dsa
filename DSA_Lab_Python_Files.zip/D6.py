# Propositional-calculus formula  ->  binary expression tree
# Symbols : variables (letters), ~ (NOT), & (AND), | (OR), > (IMPLIES), = (IFF), ( )
# Precedence (high -> low): ~  &  |  >  =
class Node:
    def __init__(self, data, left=None, right=None):
        self.data, self.left, self.right = data, left, right


class FormulaParser:
    def __init__(self, text):
        self.tokens = [c for c in text if not c.isspace()]
        self.pos = 0

    def peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else None

    def eat(self, expected=None):
        tok = self.peek()
        if tok is None or (expected and tok != expected):
            raise ValueError(f"Syntax error at position {self.pos}")
        self.pos += 1
        return tok

    def parse(self):
        root = self.iff()
        if self.peek() is not None:
            raise ValueError(f"Unexpected '{self.peek()}' at position {self.pos}")
        return root

    def _binary(self, op, next_level):
        node = next_level()
        while self.peek() == op:
            self.eat()
            node = Node(op, node, next_level())
        return node

    def iff(self):     return self._binary("=", self.implies)
    def implies(self):                              # right associative
        left = self.disj()
        if self.peek() == ">":
            self.eat()
            return Node(">", left, self.implies())
        return left
    def disj(self):    return self._binary("|", self.conj)
    def conj(self):    return self._binary("&", self.neg)

    def neg(self):
        if self.peek() == "~":
            self.eat()
            return Node("~", self.neg())            # unary: only left child used
        return self.atom()

    def atom(self):
        tok = self.peek()
        if tok == "(":
            self.eat("(")
            node = self.iff()
            self.eat(")")
            return node
        if tok is not None and tok.isalpha():
            return Node(self.eat())
        raise ValueError(f"Syntax error at position {self.pos}")


def inorder(n):
    if n is None: return ""
    if n.data == "~": return "~" + inorder(n.left)
    if n.left is None: return n.data
    return "(" + inorder(n.left) + n.data + inorder(n.right) + ")"

def prefix(n):  return "" if n is None else n.data + prefix(n.left) + prefix(n.right)
def postfix(n): return "" if n is None else postfix(n.left) + postfix(n.right) + n.data

def show(n, level=0):
    if n:
        show(n.right, level + 1)
        print("      " * level + n.data)
        show(n.left, level + 1)


if __name__ == "__main__":
    formula = input("Enter formula (e.g. (p&q)>~r|s): ")
    try:
        root = FormulaParser(formula).parse()
    except ValueError as e:
        print(e)
    else:
        print("Fully parenthesised:", inorder(root))
        print("Prefix  :", prefix(root))
        print("Postfix :", postfix(root))
        print("Tree (rotated 90 degrees, root at left):")
        show(root)
# Complexity: every token is consumed exactly once -> Time O(n), Space O(n) for the tree
# (plus O(depth) recursion stack, at most O(n)).

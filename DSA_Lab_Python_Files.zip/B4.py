# Student Record Management System using a doubly linked list
class Node:
    def __init__(self, roll, name, marks):
        self.roll, self.name, self.marks = roll, name, marks
        self.prev = self.next = None


class StudentList:
    def __init__(self):
        self.head = self.tail = None

    def search(self, roll):
        cur = self.head
        while cur:
            if cur.roll == roll:
                return cur
            cur = cur.next
        return None

    def add(self, roll, name, marks):
        if self.search(roll):
            print("Roll number already exists.")
            return
        node = Node(roll, name, marks)
        if not self.head:
            self.head = self.tail = node
        else:
            node.prev = self.tail
            self.tail.next = node
            self.tail = node
        print("Student added.")

    def delete(self, roll):
        node = self.search(roll)
        if not node:
            print("Student not found.")
            return
        if node.prev: node.prev.next = node.next
        else:         self.head = node.next
        if node.next: node.next.prev = node.prev
        else:         self.tail = node.prev
        print("Student deleted.")

    def update(self, roll, name, marks):
        node = self.search(roll)
        if not node:
            print("Student not found.")
            return
        node.name, node.marks = name, marks
        print("Record updated.")

    def sort(self, key):
        """Bubble sort (ascending) by 'roll' or 'marks' by swapping node data."""
        if not self.head:
            return
        swapped = True
        while swapped:
            swapped = False
            cur = self.head
            while cur.next:
                if getattr(cur, key) > getattr(cur.next, key):
                    cur.roll, cur.next.roll = cur.next.roll, cur.roll
                    cur.name, cur.next.name = cur.next.name, cur.name
                    cur.marks, cur.next.marks = cur.next.marks, cur.marks
                    swapped = True
                cur = cur.next

    def display(self, key="roll", descending=False):
        if not self.head:
            print("No records.")
            return
        self.sort(key)                       # list is now ascending by key
        print(f"{'Roll':<8}{'Name':<15}{'Marks':<8}")
        cur = self.tail if descending else self.head
        while cur:                           # backward walk uses 'prev' link
            print(f"{cur.roll:<8}{cur.name:<15}{cur.marks:<8}")
            cur = cur.prev if descending else cur.next


if __name__ == "__main__":
    sl = StudentList()
    while True:
        print("\n1.Add 2.Delete 3.Update 4.Search 5.Sort & Display 6.Exit")
        ch = input("Choice: ").strip()
        if ch == "1":
            sl.add(int(input("Roll No: ")), input("Name: "), float(input("Marks: ")))
        elif ch == "2":
            sl.delete(int(input("Roll No to delete: ")))
        elif ch == "3":
            sl.update(int(input("Roll No to update: ")), input("New name: "), float(input("New marks: ")))
        elif ch == "4":
            n = sl.search(int(input("Roll No to search: ")))
            print(f"Found: {n.roll}, {n.name}, {n.marks}" if n else "Not found.")
        elif ch == "5":
            key = "marks" if input("Sort by (r)oll / (m)arks: ").lower().startswith("m") else "roll"
            desc = input("Order (a)scending / (d)escending: ").lower().startswith("d")
            sl.display(key, desc)
        elif ch == "6":
            break
        else:
            print("Invalid choice.")
# add O(n) (duplicate check), delete/update/search O(n), sort O(n^2), display O(n)

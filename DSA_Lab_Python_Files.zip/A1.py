# Library borrowing records
members = {"Aarav": 5, "Bela": 0, "Chirag": 3, "Divya": 5,
           "Esha": 0, "Farhan": 2, "Gita": 3, "Hari": 5}          # member -> books borrowed
books = {"Python Basics": 12, "Data Structures": 25, "Algorithms": 18,
         "Operating Systems": 4, "DBMS": 25, "Networks": 4}        # book -> times borrowed


def average_borrowed(member_counts):
    """Average books borrowed per member."""
    total = 0
    for c in member_counts:          # O(n)
        total += c
    return total / len(member_counts) if member_counts else 0


def highest_lowest_books(book_counts):
    """Return (highest_books, lowest_books); ties are all reported."""
    hi = lo = None
    for count in book_counts.values():       # one pass: O(m)
        hi = count if hi is None or count > hi else hi
        lo = count if lo is None or count < lo else lo
    highest = [b for b, c in book_counts.items() if c == hi]
    lowest = [b for b, c in book_counts.items() if c == lo]
    return (highest, hi), (lowest, lo)


def members_with_zero(member_counts):
    """Count members whose borrow count is 0."""
    zero = 0
    for c in member_counts:                  # O(n)
        if c == 0:
            zero += 1
    return zero


def mode_of_counts(counts):
    """Mode = the borrow-count value that occurs most often."""
    freq = {}
    for c in counts:                         # O(n) using a hash map
        freq[c] = freq.get(c, 0) + 1
    best = max(freq.values())
    return [v for v, f in freq.items() if f == best], best


if __name__ == "__main__":
    member_counts = list(members.values())

    print("Average books borrowed per member:", round(average_borrowed(member_counts), 2))

    (hb, hc), (lb, lc) = highest_lowest_books(books)
    print(f"Most borrowed book(s) : {hb} ({hc} times)")
    print(f"Least borrowed book(s): {lb} ({lc} times)")

    print("Members who never borrowed:", members_with_zero(member_counts))

    modes, freq = mode_of_counts(member_counts)
    print(f"Mode of member borrow counts: {modes} (occurs {freq} times)")
    book_modes, bfreq = mode_of_counts(list(books.values()))
    print(f"Mode of book borrow counts  : {book_modes} (occurs {bfreq} times)")

    print("""
Complexity (n = members, m = books)
Operation               Time        Space
Average                 O(n)        O(1)
Highest / lowest book   O(m)        O(1)  (O(m) if all ties are listed)
Members with zero       O(n)        O(1)
Mode (hash map)         O(n)        O(k)  k = distinct borrow counts <= n
""")

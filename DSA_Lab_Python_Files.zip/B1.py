# Undo / Redo system for a text editor using two stacks

class TextEditor:
    def __init__(self):
        self.undo_stack = []      # changes currently applied (top = latest)
        self.redo_stack = []      # changes that were undone

    def make_change(self, text):
        self.undo_stack.append(text)
        self.redo_stack.clear()   # a new change invalidates the redo history
        print(f"Change made: '{text}'")

    def undo(self):
        if not self.undo_stack:
            print("Nothing to undo.")
            return
        change = self.undo_stack.pop()
        self.redo_stack.append(change)
        print(f"Undone: '{change}'")

    def redo(self):
        if not self.redo_stack:
            print("Nothing to redo.")
            return
        change = self.redo_stack.pop()
        self.undo_stack.append(change)
        print(f"Redone: '{change}'")

    def display(self):
        print("Document state:", " ".join(self.undo_stack) if self.undo_stack else "<empty>")


if __name__ == "__main__":
    editor = TextEditor()
    while True:
        print("\n1.Make Change  2.Undo  3.Redo  4.Display Document  5.Exit")
        ch = input("Choice: ").strip()
        if ch == "1":
            editor.make_change(input("Enter text to add: "))
        elif ch == "2":
            editor.undo()
        elif ch == "3":
            editor.redo()
        elif ch == "4":
            editor.display()
        elif ch == "5":
            break
        else:
            print("Invalid choice.")
# All operations (push / pop / peek) are O(1) time; space is O(n) for n changes.

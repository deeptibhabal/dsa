# Cities and populations stored in a Binary Search Tree (key = city name)
class CityNode:
    def __init__(self, name, population):
        self.name, self.population = name, population
        self.left = self.right = None


class CityBST:
    def __init__(self):
        self.root = None

    def add(self, name, population):
        node = CityNode(name, population)
        if not self.root:
            self.root = node
            return
        cur = self.root
        while True:
            if name.lower() == cur.name.lower():
                print("City already exists. Use update.")
                return
            side = "left" if name.lower() < cur.name.lower() else "right"
            nxt = getattr(cur, side)
            if nxt is None:
                setattr(cur, side, node)
                return
            cur = nxt

    def update(self, name, population):
        cur = self.root
        while cur and cur.name.lower() != name.lower():
            cur = cur.left if name.lower() < cur.name.lower() else cur.right
        if cur:
            cur.population = population
            print("Population updated.")
        else:
            print("City not found.")

    def delete(self, root, name):
        if root is None:
            print("City not found.")
            return None
        if name.lower() < root.name.lower():
            root.left = self.delete(root.left, name)
        elif name.lower() > root.name.lower():
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            if root.right is None:
                return root.left
            succ = root.right
            while succ.left:
                succ = succ.left
            root.name, root.population = succ.name, succ.population
            root.right = self.delete(root.right, succ.name)
        return root

    def display(self, descending=False):
        out, stack, cur = [], [], self.root
        while cur or stack:                       # iterative inorder (or reverse inorder)
            if cur:
                stack.append(cur)
                cur = cur.right if descending else cur.left
            else:
                cur = stack.pop()
                out.append((cur.name, cur.population))
                cur = cur.left if descending else cur.right
        return out

    def comparisons_to_search(self, name):
        count, cur = 0, self.root
        while cur:
            count += 1
            if name.lower() == cur.name.lower():
                return count, True
            cur = cur.left if name.lower() < cur.name.lower() else cur.right
        return count, False

    def height(self, node):
        return 0 if node is None else 1 + max(self.height(node.left), self.height(node.right))


if __name__ == "__main__":
    t = CityBST()
    while True:
        print("\n1.Add City  2.Delete City  3.Update Population  4.Display Ascending")
        print("5.Display Descending  6.Comparisons to search a city  7.Max comparisons  8.Exit")
        ch = input("Choice: ").strip()
        if ch == "1":
            t.add(input("City: "), int(input("Population: ")))
        elif ch == "2":
            t.root = t.delete(t.root, input("City to delete: "))
        elif ch == "3":
            t.update(input("City: "), int(input("New population: ")))
        elif ch in ("4", "5"):
            for name, pop in t.display(descending=(ch == "5")):
                print(f"  {name:<15}{pop:>12,}")
        elif ch == "6":
            c, found = t.comparisons_to_search(input("City to search: "))
            print(f"{c} comparison(s); city {'found' if found else 'NOT found'}.")
        elif ch == "7":
            print("Maximum comparisons for any search = height of tree =", t.height(t.root))
        elif ch == "8":
            break
        else:
            print("Invalid choice.")
# Max comparisons = height h of the BST: about log2(n) when balanced, n when skewed.

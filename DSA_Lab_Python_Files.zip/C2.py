# Fixed-size hash table: division method + linear probing
EMPTY, DELETED = None, "<deleted>"


class LinearProbingTable:
    def __init__(self, size=10):
        self.size = size
        self.table = [EMPTY] * size

    def hash(self, key):
        return key % self.size

    def insert(self, key):
        if self.search(key) != -1:
            print("Key already present.")
            return
        idx, first_free = self.hash(key), -1
        for i in range(self.size):
            pos = (idx + i) % self.size             # linear probe: h, h+1, h+2 ...
            if self.table[pos] is EMPTY:
                if first_free == -1:
                    first_free = pos
                break
            if self.table[pos] == DELETED and first_free == -1:
                first_free = pos
        if first_free == -1:
            print("Hash table is full.")
            return
        self.table[first_free] = key
        print(f"Inserted {key} at index {first_free}")

    def search(self, key):
        idx = self.hash(key)
        for i in range(self.size):
            pos = (idx + i) % self.size
            if self.table[pos] is EMPTY:            # reached an empty slot -> absent
                return -1
            if self.table[pos] == key:
                return pos
        return -1

    def delete(self, key):
        pos = self.search(key)
        if pos == -1:
            print("Key not found.")
        else:
            self.table[pos] = DELETED               # tombstone keeps probe chains intact
            print(f"Key {key} deleted from index {pos}")

    def display(self):
        for i, v in enumerate(self.table):
            print(f"[{i}] {'-' if v is EMPTY else v}")


if __name__ == "__main__":
    ht = LinearProbingTable(10)
    while True:
        print("\n1.Insert  2.Search  3.Delete  4.Display  5.Exit")
        ch = input("Choice: ").strip()
        if ch == "1":
            ht.insert(int(input("Key: ")))
        elif ch == "2":
            p = ht.search(int(input("Key to search: ")))
            print(f"Found at index {p}" if p != -1 else "Not found.")
        elif ch == "3":
            ht.delete(int(input("Key to delete: ")))
        elif ch == "4":
            ht.display()
        elif ch == "5":
            break
        else:
            print("Invalid choice.")

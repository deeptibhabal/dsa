# Hash table of size 10: division method + separate chaining
class ChainedHashTable:
    def __init__(self, size=10):
        self.size = size
        self.table = [[] for _ in range(size)]      # each slot holds a chain (list)

    def hash(self, key):
        return key % self.size                      # division method

    def insert(self, key, value):
        chain = self.table[self.hash(key)]
        for pair in chain:
            if pair[0] == key:                      # key exists -> update value
                pair[1] = value
                print(f"Key {key} updated.")
                return
        chain.append([key, value])                  # collision -> add to chain
        print(f"Inserted ({key}, {value}) at index {self.hash(key)}")

    def search(self, key):
        for k, v in self.table[self.hash(key)]:
            if k == key:
                return v
        return None

    def delete(self, key):
        chain = self.table[self.hash(key)]
        for pair in chain:
            if pair[0] == key:
                chain.remove(pair)
                print(f"Key {key} deleted.")
                return
        print("Key not found.")

    def display(self):
        for i, chain in enumerate(self.table):
            print(f"[{i}] -> " + (" -> ".join(f"({k}:{v})" for k, v in chain) or "empty"))


if __name__ == "__main__":
    ht = ChainedHashTable(10)
    while True:
        print("\n1.Insert  2.Search  3.Delete  4.Display  5.Exit")
        ch = input("Choice: ").strip()
        if ch == "1":
            ht.insert(int(input("Key (integer): ")), input("Value: "))
        elif ch == "2":
            v = ht.search(int(input("Key to search: ")))
            print(f"Value = {v}" if v is not None else "Key not found.")
        elif ch == "3":
            ht.delete(int(input("Key to delete: ")))
        elif ch == "4":
            ht.display()
        elif ch == "5":
            break
        else:
            print("Invalid choice.")
# Average O(1) per operation (load factor alpha = n/10), worst case O(n) if all keys collide.

# Extendible hashing: directory doubles / buckets split when a bucket overflows
class Bucket:
    def __init__(self, depth, capacity):
        self.depth = depth                  # local depth
        self.capacity = capacity
        self.items = {}


class ExtendibleHashTable:
    def __init__(self, bucket_capacity=2):
        self.capacity = bucket_capacity     # threshold for keys per bucket
        self.global_depth = 1
        self.directory = [Bucket(1, bucket_capacity), Bucket(1, bucket_capacity)]

    @staticmethod
    def _hash(key):
        if isinstance(key, int):
            return key
        h = 0
        for ch in str(key):                 # deterministic string hash
            h = h * 31 + ord(ch)
        return h

    def _index(self, key):
        return self._hash(key) & ((1 << self.global_depth) - 1)   # last 'gd' bits

    def insert(self, key, value):
        bucket = self.directory[self._index(key)]
        if key in bucket.items or len(bucket.items) < bucket.capacity:
            bucket.items[key] = value
            return
        if self.global_depth >= 16:
            raise RuntimeError("Too many colliding keys (max depth reached).")
        if bucket.depth == self.global_depth:   # directory must double first
            self.directory = self.directory + self.directory
            self.global_depth += 1
        self._split(bucket)
        self.insert(key, value)                 # retry after split

    def _split(self, bucket):
        bucket.depth += 1
        new_bucket = Bucket(bucket.depth, self.capacity)
        bit = 1 << (bucket.depth - 1)
        for i in range(len(self.directory)):    # re-point half the directory entries
            if self.directory[i] is bucket and (i & bit):
                self.directory[i] = new_bucket
        old_items, bucket.items = bucket.items, {}
        for k, v in old_items.items():          # redistribute keys
            target = new_bucket if self._hash(k) & bit else bucket
            target.items[k] = v

    def search(self, key):
        return self.directory[self._index(key)].items.get(key)

    def delete(self, key):
        bucket = self.directory[self._index(key)]
        if key in bucket.items:
            del bucket.items[key]
            print(f"Key {key} deleted.")
        else:
            print("Key not found.")

    def display(self):
        print(f"Global depth = {self.global_depth}")
        seen = []
        for i, b in enumerate(self.directory):
            tag = "" if any(b is s for s in seen) else f"  items={b.items}"
            if not tag:
                tag = "  (same bucket as above)"
            else:
                seen.append(b)
            print(f"  dir[{i:0{self.global_depth}b}] -> bucket (local depth {b.depth}){tag}")


if __name__ == "__main__":
    ht = ExtendibleHashTable(bucket_capacity=2)
    while True:
        print("\n1.Insert  2.Search  3.Delete  4.Display  5.Exit")
        ch = input("Choice: ").strip()
        if ch == "1":
            raw = input("Key (integer or text): ")
            key = int(raw) if raw.lstrip("-").isdigit() else raw
            ht.insert(key, input("Value: "))
        elif ch == "2":
            raw = input("Key to search: ")
            key = int(raw) if raw.lstrip("-").isdigit() else raw
            v = ht.search(key)
            print(f"Value = {v}" if v is not None else "Key not found.")
        elif ch == "3":
            raw = input("Key to delete: ")
            ht.delete(int(raw) if raw.lstrip("-").isdigit() else raw)
        elif ch == "4":
            ht.display()
        elif ch == "5":
            break
        else:
            print("Invalid choice.")
# Search O(1); insert O(1) amortised (a split costs O(directory size)).

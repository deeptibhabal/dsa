# Binary Search Tree: insertion, deletion, display, search
class Node:
    def __init__(self, key):
        self.key = key
        self.left = self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, key):
        if root is None:
            return Node(key)
        if key < root.key:
            root.left = self.insert(root.left, key)
        elif key > root.key:
            root.right = self.insert(root.right, key)
        else:
            print("Duplicate key ignored.")
        return root

    def search(self, root, key):
        while root and root.key != key:
            root = root.left if key < root.key else root.right
        return root is not None

    def _min_node(self, node):
        while node.left:
            node = node.left
        return node

    def delete(self, root, key):
        if root is None:
            print("Key not found.")
            return None
        if key < root.key:
            root.left = self.delete(root.left, key)
        elif key > root.key:
            root.right = self.delete(root.right, key)
        else:
            if root.left is None:                 # 0 or 1 child
                return root.right
            if root.right is None:
                return root.left
            succ = self._min_node(root.right)     # 2 children: inorder successor
            root.key = succ.key
            root.right = self.delete(root.right, succ.key)
        return root

    def inorder(self, r, out):
        if r: self.inorder(r.left, out); out.append(r.key); self.inorder(r.right, out)
        return out

    def preorder(self, r, out):
        if r: out.append(r.key); self.preorder(r.left, out); self.preorder(r.right, out)
        return out

    def postorder(self, r, out):
        if r: self.postorder(r.left, out); self.postorder(r.right, out); out.append(r.key)
        return out


if __name__ == "__main__":
    t = BST()
    while True:
        print("\n1.Insert  2.Delete  3.Display  4.Search  5.Exit")
        ch = input("Choice: ").strip()
        if ch == "1":
            t.root = t.insert(t.root, int(input("Key: ")))
        elif ch == "2":
            t.root = t.delete(t.root, int(input("Key to delete: ")))
        elif ch == "3":
            print("Inorder  :", t.inorder(t.root, []))
            print("Preorder :", t.preorder(t.root, []))
            print("Postorder:", t.postorder(t.root, []))
        elif ch == "4":
            print("Found" if t.search(t.root, int(input("Key to search: "))) else "Not found")
        elif ch == "5":
            break
        else:
            print("Invalid choice.")
# Insert/search/delete: O(h) -> O(log n) average, O(n) worst (skewed tree). Traversals O(n).

# Pizza delivery in minimum time
# Graph: nodes = shop + customer locations, edge weight = travel time (minutes).
# Step 1: Dijkstra (min-heap)  -> shortest travel time between every pair of locations.
# Step 2: Held-Karp bitmask DP -> best order to visit ALL customers with minimum total time.
import heapq

graph = {                       # undirected weighted graph (time in minutes)
    "Shop": {"A": 4, "B": 2},
    "A":    {"Shop": 4, "B": 1, "C": 5},
    "B":    {"Shop": 2, "A": 1, "C": 8, "D": 10},
    "C":    {"A": 5, "B": 8, "D": 3},
    "D":    {"B": 10, "C": 3},
}
INF = float("inf")


def dijkstra(src):
    dist = {v: INF for v in graph}
    dist[src] = 0
    heap = [(0, src)]
    while heap:
        d, u = heapq.heappop(heap)
        if d > dist[u]:
            continue
        for v, w in graph[u].items():
            if d + w < dist[v]:
                dist[v] = d + w
                heapq.heappush(heap, (dist[v], v))
    return dist                                    # O((V + E) log V)


def best_delivery_route(start="Shop", return_to_shop=True):
    customers = [v for v in graph if v != start]
    k = len(customers)
    dist = {v: dijkstra(v) for v in graph}         # all-pairs shortest times

    # dp[mask][i] = least time to start at 'start', visit customers in mask, end at customer i
    dp = [[INF] * k for _ in range(1 << k)]
    parent = [[-1] * k for _ in range(1 << k)]
    for i in range(k):
        dp[1 << i][i] = dist[start][customers[i]]
    for mask in range(1 << k):
        for i in range(k):
            if dp[mask][i] == INF or not (mask >> i) & 1:
                continue
            for j in range(k):
                if (mask >> j) & 1:
                    continue
                nmask = mask | (1 << j)
                cost = dp[mask][i] + dist[customers[i]][customers[j]]
                if cost < dp[nmask][j]:
                    dp[nmask][j] = cost
                    parent[nmask][j] = i

    full = (1 << k) - 1
    best, last = INF, -1
    for i in range(k):
        total = dp[full][i] + (dist[customers[i]][start] if return_to_shop else 0)
        if total < best:
            best, last = total, i

    order, mask = [], full                         # rebuild the route
    while last != -1:
        order.append(customers[last])
        prev = parent[mask][last]
        mask ^= 1 << last
        last = prev
    order.reverse()
    return best, [start] + order + ([start] if return_to_shop else [])


if __name__ == "__main__":
    print("Shortest time from Shop to each location:")
    for place, t in dijkstra("Shop").items():
        print(f"  {place}: {t} min")

    total, route = best_delivery_route("Shop", return_to_shop=True)
    print("\nBest delivery order (each leg follows the shortest path):\n ", " -> ".join(route))
    print("Total time (minutes):", total)
# Dijkstra: O((V+E) log V) per source.  Held-Karp: O(2^k * k^2) for k customers
# (the exact problem is the Travelling Salesman Problem, so it is only practical for small k).
